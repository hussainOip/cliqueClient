import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lead-profile',
  templateUrl: './lead-profile.component.html',
  styleUrls: ['./lead-profile.component.css']
})
export class LeadProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
