
      (function(b, s, p, o, r, t) {
        b["broadage"] = b["broadage"] || [];
        if (!b["broadage"].length) {
          r = document.createElement(s);
          t = document.getElementsByTagName(s)[0];
          r.async = true;
          r.src = p;
          t.parentNode.insertBefore(r, t);
        }
        b["broadage"].push({ "bundleId": o.bundleId, "widgets": o.widgets, "accountId": o.accountId });
      })(window, "script", "//cdn-saas.broadage.com/widgets/loader/loader.js", {
        "bundleId": ["all-ls"],
        "accountId": "d4dda510-262c-4b68-b88e-5019b75ffac7",
        "widgets": {
          "liveScore": [{
            "element": "DOM_element_id_in_your_website_1635331960421",
            "coverageId": "cea4dc1e-e6fa-4bb2-86dd-e29f568050ce",
            "options": {
              "goalSound": true,
              "webNotification": true,
              "sportFilter": false,
              "sportId": 2
            }
          }]
        }
      });


  (function(b, s, p, o, r, t) {
    b["broadage"] = b["broadage"] || [];
    if (!b["broadage"].length) {
      r = document.createElement(s);
      t = document.getElementsByTagName(s)[0];
      r.async = true;
      r.src = p;
      t.parentNode.insertBefore(r, t);
    }
    b["broadage"].push({ "bundleId": o.bundleId, "widgets": o.widgets, "accountId": o.accountId });
  })(window, "script", "//cdn-saas.broadage.com/widgets/loader/loader.js", {
    "bundleId": ["all-ls"],
    "accountId": "d4dda510-262c-4b68-b88e-5019b75ffac7",
    "widgets": {
      "liveScore": [{
        "element": "DOM_element_id_in_your_website_1635332956204",
        "coverageId": "cea4dc1e-e6fa-4bb2-86dd-e29f568050ce",
        "options": {
          "goalSound": true,
          "webNotification": true,
          "sportFilter": false,
          "sportId": 10
        }
      }]
    }
  });

  (function(b, s, p, o, r, t) {
    b["broadage"] = b["broadage"] || [];
    if (!b["broadage"].length) {
      r = document.createElement(s);
      t = document.getElementsByTagName(s)[0];
      r.async = true;
      r.src = p;
      t.parentNode.insertBefore(r, t);
    }
    b["broadage"].push({ "bundleId": o.bundleId, "widgets": o.widgets, "accountId": o.accountId });
  })(window, "script", "//cdn-saas.broadage.com/widgets/loader/loader.js", {
    "bundleId": ["all-ls"],
    "accountId": "d4dda510-262c-4b68-b88e-5019b75ffac7",
    "widgets": {
      "liveScore": [{
        "element": "DOM_element_id_in_your_website_1635333048507",
        "coverageId": "cea4dc1e-e6fa-4bb2-86dd-e29f568050ce",
        "options": {
          "goalSound": true,
          "webNotification": true,
          "sportFilter": false,
          "sportId": 9
        }
      }]
    }
  });




    (function(b, s, p, o, r, t) {
      b["broadage"] = b["broadage"] || [];
      if (!b["broadage"].length) {
        r = document.createElement(s);
        t = document.getElementsByTagName(s)[0];
        r.async = true;
        r.src = p;
        t.parentNode.insertBefore(r, t);
      }
      b["broadage"].push({ "bundleId": o.bundleId, "widgets": o.widgets, "accountId": o.accountId });
    })(window, "script", "//cdn-saas.broadage.com/widgets/loader/loader.js", {
      "bundleId": ["all-ls"],
      "accountId": "d4dda510-262c-4b68-b88e-5019b75ffac7",
      "widgets": {
        "liveScore": [{
          "element": "DOM_element_id_in_your_website_1635333116676",
          "coverageId": "cea4dc1e-e6fa-4bb2-86dd-e29f568050ce",
          "options": {
            "sportFilter": false,
            "sportId": 11
          }
        }]
      }
    });