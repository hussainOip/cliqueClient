export const environment = {
  production: true,
  baseUrl:"https://click-server105.herokuapp.com/api",
  baseUrlForImage:"https://click-server105.herokuapp.com/",
  baseUrlForSocket:"https://click-server105.herokuapp.com"
};
